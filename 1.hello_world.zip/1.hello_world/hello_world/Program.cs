﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hello_world
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello World");
            Console.Read();
        }
    }
}
