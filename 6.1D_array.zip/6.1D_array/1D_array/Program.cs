﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1D_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[3];
            a[0] = 11;
            a[1] = 22;
            a[2] = 33;

            foreach (int i in a)
            {
                Console.WriteLine(i);
            }
            Console.Read();
        }
    }
}
